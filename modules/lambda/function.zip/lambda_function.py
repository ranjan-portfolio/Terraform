from client.weather_api import get_weather_forecast
from typing import List, Dict, Any
import requests
import json

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
   query_params = event.get("queryStringParameters") or {}
   city = query_params.get("city", "London")

   try:
      if event["httpMethod"] == "OPTIONS":
        return {
                "statusCode": 200,
                "headers": {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "x-api-key,Content-Type",
                    "Access-Control-Allow-Methods": "GET,OPTIONS"
                },
                "body": ""
               }
      
      data=get_weather_forecast(city)
      return {
            "statusCode": 200,
            "headers": 
            {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "x-api-key,Content-Type",
                "Access-Control-Allow-Methods": "GET,OPTIONS"
            },
            "body": data # Return your list of dicts as JSON string
        }
   
   except Exception as e:
        if args := getattr(e, "args", None):
             if args and len(args) > 0:
                 data = args[0]
                 if isinstance(data, dict) and 'cod' in data and 'message' in data:
                     return {
                         "statusCode": int(data['cod']),
                         "body": 'error:' + data['cod'] + ':' + data['message']
                     }
        else:
             return {
                 "statusCode": 500,
                 "body": 'error:500:Internal Server Error'
             }

