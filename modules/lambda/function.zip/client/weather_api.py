import requests
import json
from  secrets.secrets import get_secret
from to.forecast import Forecast
from typing import List, Dict, Any
import logging


forecast_list=[]

def get_weather_forecast(city:str)-> str:
 logging.info("Inside weather forecast")
 data=call_weather_api(city)

 if data["cod"] == "200":
  forecast_list.clear()
  for forecast_data in data["list"]:
        date=forecast_data["dt_txt"]
        actual_temp=forecast_data["main"]["temp"]
        feels_like=forecast_data["main"]["feels_like"]
        weather=forecast_data["weather"][0]["main"]
        forecast_list.append(Forecast(date,actual_temp,feels_like,weather))

  json_data = json.dumps(
                   [f.to_dict() for f in forecast_list],
                   indent=2
             )
  return json_data
 
 else:
      raise requests.exceptions.HTTPError(data)   
 

def call_weather_api(city:str)->Any:
 logging.info("Inside call_weather_api")
 key=get_secret()
 url = "https://api.openweathermap.org/data/2.5/forecast"
 params={
    "q":city,
    "appid":key,
    "units":"metric"
 }
 response=requests.get(url=url,params=params)
 data=response.json()
 return data




 


