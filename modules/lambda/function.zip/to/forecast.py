class Forecast:

    def __init__(self,date,actual_temp,feels_like,weather_type):
        self.date=date
        self.actual_temp=actual_temp
        self.feels_like=feels_like
        self.weather_type=weather_type
    
    def to_dict(self):
        return {
            "date": self.date,
            "temp": self.actual_temp,
            "feels_like": self.feels_like,
            "weather": self.weather_type
        }